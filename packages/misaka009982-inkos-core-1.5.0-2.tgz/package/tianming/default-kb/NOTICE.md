# InkOS 内置天命默认知识库

这是 InkOS 随包附带的天命式知识库基线，用于在用户没有提供外部天命目录时，仍然可以通过：

```bash
inkos lore import-tianming [book-id]
```

把一组可编辑的小说项目管理模板导入到当前书籍。

本目录保持与 Tianming KB 导入器兼容的文件名：

- `世界观规则.md`
- `角色档案.md`
- `档案事件.md`
- `文风样本.md`
- `世界基石.md`
- `aesthetic/ai-signature-blacklist.md`
- `aesthetic/style-genesis.md`

这些文件是 InkOS 内置模板，面向设定胶囊、Plan/Compose 选择、Writer/Auditor 风格约束和统一黑名单编译流程设计。
